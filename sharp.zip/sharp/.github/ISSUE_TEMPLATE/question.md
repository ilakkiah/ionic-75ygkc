---
name: Question
about: For help understanding an existing feature
labels: question

---

<!-- If this issue relates to installation, please use https://github.com/lovell/sharp/issues/new?labels=installation&template=installation.md instead. -->

What are you trying to achieve?

Have you searched for similar questions?

Are you able to provide a minimal, standalone code sample that demonstrates this question?

Are you able to provide a sample image that helps explain the question?
