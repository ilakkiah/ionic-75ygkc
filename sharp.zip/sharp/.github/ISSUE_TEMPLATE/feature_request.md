---
name: Feature request
about: Suggest an idea
labels: enhancement

---

What are you trying to achieve?

Have you searched for similar feature requests?

What would you expect the API to look like?

What alternatives have you considered?

Is there a sample image that helps explain?
